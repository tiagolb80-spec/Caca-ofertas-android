# Caça Ofertas — projeto inicial Android + API

Projeto Android novo para o app Caça Ofertas. O Android carrega a interface local e pode ser compilado pelo GitHub Actions para gerar um APK instalável.

## O que já está no projeto
- Interface em português com campo de busca, CEP, filtro de frete grátis e opção de busca de cupons.
- Aplicativo Android Java/WebView com ícone vetorial.
- Workflow `.github/workflows/build-apk.yml` que compila o APK e publica o artefato `Caca-Ofertas-APK`.
- API Python/FastAPI inicial com busca de produtos via SerpApi Google Shopping e busca complementar de páginas públicas de promoções/cupons.
- Filtro de frete grátis conservador: só considera grátis quando a fonte declara explicitamente isso.

## Importante: estado atual
Este é um **protótipo funcional de interface e integração inicial**, não um agregador comercial completo ainda. Para a busca real, é obrigatório hospedar a API e configurar uma chave SerpApi no servidor. O APK sozinho não fará pesquisa real até receber o endereço da API. A busca por páginas de cupom encontra páginas relacionadas, mas não valida automaticamente códigos; validade, estoque e frete precisam ser confirmados na loja. O CEP é recebido pela API, mas ainda não há consulta de frete específica por CEP integrada.

## Gerar APK pelo GitHub usando o celular
1. Crie um repositório novo no GitHub chamado `caca-ofertas-android`.
2. Extraia o conteúdo deste ZIP e envie todos os arquivos e pastas para a raiz do repositório (incluindo `.github`).
3. Abra a aba **Actions** e execute **Build Caça Ofertas APK**; também compila automaticamente a cada push.
4. Abra a execução concluída e baixe o artefato `Caca-Ofertas-APK`. Dentro dele estará `app-debug.apk`.
5. Instale no Android permitindo a instalação desse APK quando solicitado.

## Ativar busca real
1. Hospede a pasta `backend` em um serviço que execute Docker ou Python (por exemplo, um serviço web gerenciado).
2. Defina a variável de ambiente `SERPAPI_KEY` nas configurações secretas do serviço. **Não coloque essa chave no código Android, no GitHub público ou neste ZIP.**
3. Teste `https://SEU-SERVIDOR/health` e confirme `provider_configured: true`.
4. A interface ainda precisa receber a URL pública do serviço: abra `app/src/main/assets/index.html`, localize `let API_BASE=localStorage.getItem('apiBase')||'';` e substitua por `let API_BASE='https://SEU-SERVIDOR';`, sem barra no final. Depois compile novamente o APK.

## Próximas integrações para versão completa
- Fontes oficiais/afiliadas de marketplaces (quando disponíveis) para resultados mais confiáveis e links de compra.
- Cotação de frete por CEP via API autorizada de cada loja/marketplace.
- Provedor estruturado de cupons ou parcerias com lojas; teste de cupom não deve ser prometido sem validação real.
- Banco de dados e tarefa agendada para histórico de preços, favoritos e alertas push.
- Política de privacidade, termos de uso, monitoramento de erros e testes em aparelho real antes da publicação.

## Executar API localmente
```bash
cd backend
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export SERPAPI_KEY='SUA_CHAVE'  # PowerShell: $env:SERPAPI_KEY='SUA_CHAVE'
uvicorn main:app --reload --port 8000
```
A API fica em `http://localhost:8000`; documentação interativa em `/docs`. Para o APK instalado no telefone, use uma URL pública HTTPS, não `localhost`.
